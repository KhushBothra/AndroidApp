package com.example.myapplication2;

import androidx.appcompat.app.AppCompatActivity;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.nfc.FormatException;
import android.nfc.NdefMessage;
import android.nfc.NdefRecord;
import android.nfc.NfcAdapter;
import android.nfc.Tag;
import android.nfc.tech.Ndef;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.myapplication2.ui.main.MainFragment;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;

public class MainActivity extends AppCompatActivity {

    private NfcAdapter nfcAdapter;
    PendingIntent pendingIntent;
    IntentFilter intentFilter[];
    boolean writeMode;
    Tag myTag;
    Context context;
    public String code;


    public static final String Error_Detected="No NFC Tag Detected";
    public static final String Write_Success="Text Written Successfully";
    public static final String Write_Error="Error During Writing";

    TextView textView6;
    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if (savedInstanceState == null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.container, MainFragment.newInstance())
                    .commitNow();
        }
        nfcAdapter = NfcAdapter.getDefaultAdapter(this);
        textView6=findViewById(R.id.textView6);
        button=findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){

                try{
                    if(myTag==null){
                        Toast.makeText(context, Error_Detected, Toast.LENGTH_LONG).show();
                    }else{
                        write(code, myTag);
                        Toast.makeText(context, Write_Success, Toast.LENGTH_LONG).show();
                    }
                }catch (Exception e){
                    Toast.makeText(context, Write_Error, Toast.LENGTH_LONG).show();
                    e.printStackTrace();
                }
            }
        });
        context=this;
//        if(nfcAdapter==null){
//            Toast.makeText(this, "This device Does Not Support NFC", Toast.LENGTH_SHORT).show();
//            finish();
//        }
        readfromIntent(getIntent());
        pendingIntent=PendingIntent.getActivity(this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
        IntentFilter tagDetected=new IntentFilter(NfcAdapter.ACTION_TAG_DISCOVERED);
        tagDetected.addCategory(Intent.CATEGORY_DEFAULT);
        intentFilter=new IntentFilter[]{tagDetected};
    }

    public void readfromIntent(Intent intent) {
        String action=intent.getAction();
        if(NfcAdapter.ACTION_TAG_DISCOVERED.equals(action)
            || NfcAdapter.ACTION_TECH_DISCOVERED.equals(action)
            || NfcAdapter.ACTION_NDEF_DISCOVERED.equals(action)){

            Parcelable[] raw=intent.getParcelableArrayExtra(NfcAdapter.EXTRA_NDEF_MESSAGES);
            NdefMessage[] msgs=null;
            if(raw!=null){
                msgs=new NdefMessage[raw.length];
                for(int i=0; i< raw.length; i++)
                    msgs[i]=(NdefMessage) raw[i];
            }
            buildTagViews(msgs);
        }
    }


        private void buildTagViews (NdefMessage[] msgs) {

            if (msgs == null || msgs.length == 0) return;

            String text ="";
            byte[] payload= msgs[0].getRecords()[0].getPayload();
            String textEncoding = ((payload [0] & 128)==0) ? "UTF-8" : "UTF-16";
            int languageCodeLength = payload [0] & 0063;

            try{
                text=new String(payload, languageCodeLength+1, payload.length-languageCodeLength-1, textEncoding);
            } catch (UnsupportedEncodingException e) {
                Log.e("UnsupportedEncoding", e.toString());
            }
            textView6.setText(text);
        }

        private void write(String text, Tag tag) throws IOException, FormatException{
            NdefRecord[] records={createRecord(text)};
            NdefMessage message=new NdefMessage(records);
            Ndef ndef= Ndef.get(tag);
            ndef.connect();
            ndef.writeNdefMessage(message);
            ndef.close();
        }

        private NdefRecord createRecord(String text) throws UnsupportedEncodingException{
            String lang="en";
            byte[] textBytes=text.getBytes();
            byte[] langBytes=text.getBytes("US-ASCII");
            int langLen=langBytes.length;
            int textLen=textBytes.length;
            byte[] payload=new byte[1+langLen+textLen];

            payload[0]=(byte) langLen;

            System.arraycopy(langBytes, 0, payload, 1, langLen);
            System.arraycopy(textBytes, 0, payload, 1+langLen, textLen);

            NdefRecord recorfNFC=new NdefRecord(NdefRecord.TNF_WELL_KNOWN, NdefRecord.RTD_TEXT, new byte[0], payload);
            return recorfNFC;
        }

        protected void onNewIntent(Intent intent) {
            super.onNewIntent(intent);
            setIntent(intent);
            readfromIntent(intent);
            if(NfcAdapter.ACTION_TAG_DISCOVERED.equals(intent.getAction())){
                myTag=intent.getParcelableExtra(NfcAdapter.EXTRA_TAG);
            }
        }

    protected void onPause() {
        super.onPause();
        WriteModeOff();
    }

    protected void onResume() {
        super.onResume();
        WriteModeOn();
    }

    private void WriteModeOn(){
        writeMode=true;
        nfcAdapter.enableForegroundDispatch(this, pendingIntent, intentFilter, null);
    }

    private void WriteModeOff(){
        writeMode=false;
        nfcAdapter.disableForegroundDispatch(this);
    }

}
























//package com.example.myapplication2;
//
//import android.app.Activity;
//import android.app.PendingIntent;
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.Intent;
//import android.content.IntentFilter;
//import android.nfc.NfcAdapter;
//import android.nfc.tech.IsoDep;
//import android.nfc.tech.MifareClassic;
//import android.nfc.tech.MifareUltralight;
//import android.nfc.tech.Ndef;
//import android.nfc.tech.NfcA;
//import android.nfc.tech.NfcB;
//import android.nfc.tech.NfcF;
//import android.nfc.tech.NfcV;
//import android.os.Bundle;
//import android.util.Log;
//import android.view.Menu;
//import android.widget.TextView;
//
//public class MainActivity extends Activity {
//
//    // list of NFC technologies detected:
//    private final String[][] techList = new String[][] {
//            new String[] {
//                    NfcA.class.getName(),
//                    NfcB.class.getName(),
//                    NfcF.class.getName(),
//                    NfcV.class.getName(),
//                    IsoDep.class.getName(),
//                    MifareClassic.class.getName(),
//                    MifareUltralight.class.getName(), Ndef.class.getName()
//            }
//    };
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_main);
//    }
//
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.main_activity, menu);
//        return true;
//    }
//
//    @Override
//    protected void onResume() {
//        super.onResume();
//        // creating pending intent:
//        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, new Intent(this, getClass()).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP), 0);
//        // creating intent receiver for NFC events:
//        IntentFilter filter = new IntentFilter();
//        filter.addAction(NfcAdapter.ACTION_TAG_DISCOVERED);
//        filter.addAction(NfcAdapter.ACTION_NDEF_DISCOVERED);
//        filter.addAction(NfcAdapter.ACTION_TECH_DISCOVERED);
//        // enabling foreground dispatch for getting intent from NFC event:
//        NfcAdapter nfcAdapter = NfcAdapter.getDefaultAdapter(this);
//        nfcAdapter.enableForegroundDispatch(this, pendingIntent, new IntentFilter[]{filter}, this.techList);
//    }
//
//    @Override
//    protected void onPause() {
//        super.onPause();
//        // disabling foreground dispatch:
//        NfcAdapter nfcAdapter = NfcAdapter.getDefaultAdapter(this);
//        nfcAdapter.disableForegroundDispatch(this);
//    }
//
//    @Override
//    protected void onNewIntent(Intent intent) {
//        if (intent.getAction().equals(NfcAdapter.ACTION_TAG_DISCOVERED)) {
//            ((TextView)findViewById(R.id.textView6)).setText(
//                    "NFC Tag\n" +
//                            ByteArrayToHexString(intent.getByteArrayExtra(NfcAdapter.EXTRA_ID)));
//        }
//    }
//
//    private String ByteArrayToHexString(byte [] inarray) {
//        int i, j, in;
//        String [] hex = {"0","1","2","3","4","5","6","7","8","9","A","B","C","D","E","F"};
//        String out= "";
//
//        for(j = 0 ; j < inarray.length ; ++j)
//        {
//            in = (int) inarray[j] & 0xff;
//            i = (in >> 4) & 0x0f;
//            out += hex[i];
//            i = in & 0x0f;
//            out += hex[i];
//        }
//        return out;
//    }
//
//}